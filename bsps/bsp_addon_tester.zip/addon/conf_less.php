<?php

defined('KIMB_CMS') or die('No clean Request');

echo 'conf less tester';


?>
