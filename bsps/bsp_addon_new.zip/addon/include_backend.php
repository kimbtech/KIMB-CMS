<?php

defined('KIMB_Backend') or die('No clean Request');

echo 'test backend new';


?>
