<?php

defined('KIMB_CMS') or die('No clean Request');

echo 'test first new';


?>
