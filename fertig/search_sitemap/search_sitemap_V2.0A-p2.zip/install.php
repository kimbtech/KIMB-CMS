<?php

//Add-on API wish
$a = new ADDonAPI( 'search_sitemap' );
$a->set_fe( 'vorn', 'a' , 'no' );

?>
