<?php

//Add-on API wish
$a = new ADDonAPI( 'kimbea' );
$a->set_be( 'vorn', 'all' , 'no' );
$a->set_fe( 'vorn', 'a' , 'all' );

?>
